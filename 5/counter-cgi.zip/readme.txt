Flash Hit Counter: By ZuRG and SeanM

To set up the hit counter, simply upload the files to your server, and CHMOD them to 755. Sorry, it doesnt work if you cant set your file attributes.

You are free to edit the fla, but we reccomend you dont edit the cgi files, cause you will more than likely mess them up =)