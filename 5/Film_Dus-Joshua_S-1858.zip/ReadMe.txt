Dust & Scratches

Joshua Sullivan
October 16, 2000

I've attempted to reproduce the look of film that's seen
some wear and tear. Including this in your flash files is
simple, simply copy the "*Dust & Scratches" movie clip
into its own layer in your movie and align its
registration point to 0,0. Be sure to set the "stage_width"
and "stage_height" variables in the first frame of
"*Dust & Scratches" or the effect might not cover the
entire stage.

The first frame of "Line Master" and "Speck Master" set
the paremeters for both clips if you're of a mind to do
some tweaking. To add more dust and scratches, simply drop
more copies of the "Master" clips into "*Dust & Scratches".

I'd be interested to see what people use this for. If you
feel like it, send me a URL.