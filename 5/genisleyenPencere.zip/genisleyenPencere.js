function genisleyenPencere(adres) {

if (document.all) 
{
	var genislikYap = 400;
	var genislikArtir = 2;
	var yukseklikYap = 400;
	var yukseklikArtir = 2;
	
	var yeniPencere = window.open("","","left=200,top=140,width=1,height=1,scrollbars=1");
	for (yukseklik = 1; yukseklik < yukseklikYap; yukseklik += yukseklikArtir) 
	{
	yeniPencere.resizeTo("1", yukseklik);
	}
	
	for (genislik = 1; genislik < genislikYap; genislik += genislikArtir) 
	{
	yeniPencere.resizeTo(genislik, yukseklik);
	}
	
	yeniPencere.location = adres;
}
else
	window.location = adres;
}