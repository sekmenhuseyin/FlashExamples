Amplitude Xtra
Demonstration Movie

This Director 8 movie requires the Amplitude xtra V2.1 for 
Macintosh and Windows available from,

http://www.marmalademedia.com.au/