CREATE TABLE fwguestbook (
   date varchar(25) NOT NULL,
   name varchar(50) NOT NULL,
   email varchar(50) NOT NULL,
   url varchar(200) NOT NULL,
   title varchar(200) NOT NULL,
   comment blob NOT NULL,
   ip varchar(100) NOT NULL,
   id int(4) DEFAULT '0' NOT NULL auto_increment,
   PRIMARY KEY (id)
);
