xmlphotoalbum v.4.0
release date : 06.06.2008
developed by Selcuk ARTUT and Alp TUGAN
http://www.xmlphotoalbum.com

Added features:
Actionscript 3.0
Overlayed captioning
Thumbnail menu

coming features:
Gallery
Video play option

for any questions:
info@xmlphotoalbum.com

How to use:

In Flash AS3 window, you need to type the following;

import com.*;
var gallery:XmlPhotoAlbum = new XmlPhotoAlbum();
addChild(gallery);


For settings please refer to 
data/config.xml




Free of use

we'd appreciate if you could send us the links to your websites when you apply the component.

